package main.java.api;


import main.java.controller.MyStack;
import main.java.entry.Position;

public interface MazeAlgorithm {

    /**
     * 利用递归深度遍历回溯最短路径算法
     */
    //mazeArray 传迷宫二维数组 en[] 是入口位置   stackUtil是初始位置  minsu 是最短距离栈
    void getMinStack(int[] en, int[][] mazeArray, MyStack<Position> stackUtil, MyStack<Position> minStackUtil);

}
