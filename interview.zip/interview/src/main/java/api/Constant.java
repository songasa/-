package main.java.api;

public interface Constant {
    //右方向
    int RIGHT = 0;

    //下方向
    int DOWN = 1;

    //左方向
    int LEFT = 2;

    //上方向
    int UP = 3;
}
