package main.java.transfer;

public class EntrancePosition {

    //返回入口位置
    public static int[] entrance(String file){
        int m = file.indexOf("(");
        int n = file.indexOf(")");
        int t = file.indexOf(",");
        int[] en = new int[2];
        int r = 0;
        int c = 0;
        //从输入中读取 入口的位置 char r c
        for(int i=m+1;i<t;i++){
            String s = String.valueOf(file.charAt(i));
            int q = Integer.parseInt(s);
            r = r*10 + q;
        }
        for(int j=t+1;j<n;j++){
            String s = String.valueOf(file.charAt(j));
            int q = Integer.parseInt(s);
            c = c*10 + q;
        }
        en[0] =  r;
        en[1] = c;
        return en;
    }
}
