package main.java.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

/**
 * @author song
 */
public class RCMaze {

    //返回迷宫行数 Row
    public static int RMaze(String FileName) throws FileNotFoundException {
        int l = 0;  //迷宫文化行数赋值初始为0
        File file = new File(FileName);
        try (Scanner sc = new Scanner(new FileReader(file.getPath()))) {
            while (sc.hasNextLine()) {    //按行读取字符串
                String line = sc.nextLine();
                l++;
            }
            return l;
        }
    }

    //返回迷宫列数 Column
    public static int CMaze(String FileName) throws FileNotFoundException {
        int x = 0;  //迷宫列数初始定义
        File file = new File(FileName);
        try (Scanner sc = new Scanner(new FileReader(file.getPath()))) {
            while (sc.hasNextLine()) {    //按行读取字符串
                String line = sc.nextLine();
                x = (char) line.length();
            }
            return x;
        }
    }

}
