package main.java.controller;

import java.util.ArrayList;
import java.util.List;

public class MyStack<T> {
    public List<T> list = new ArrayList<>();
    public MyStack() {
    }
    public int size(){
        return list.size();
    }

    //存放泛型 到ArrayList
    public void push(T t){
        list.add(t);
    }

    //获取ArrayList中顶部
    public T peek(){
        return list.get(list.size()-1);
    }

    //获取ArrayList中顶部 并删除顶部元素
    public T pop(){
        T t = list.get(list.size()-1);
        list.remove(list.size()-1);
        return t;
    }

    //返回ArrayList中是否存在此数据t  存在返回true
    public boolean contains(T t){
        boolean flag = false;
        for (T t1 : this.list) {
            if(t1.equals(t)){
                flag = true;
            }
        }
        return flag;
    }

    //清除栈
    public void clear() {
        list.clear();
    }
}
