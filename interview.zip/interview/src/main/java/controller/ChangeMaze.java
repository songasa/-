package main.java.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class ChangeMaze {

    //讲迷宫文件返回二维数组
    public static int[][] Change(String FileName,int t,int p) throws FileNotFoundException {
        int [][] a = new int[t][p];
        int l = 0;  //迷宫文化行数赋值初始为0
        File file = new File(FileName);
        try (Scanner sc = new Scanner(new FileReader(file.getPath()))) {
            while (sc.hasNextLine()) {    //按行读取字符串
                String line = sc.nextLine();
                for(int i=0;i<p;i++){
                    if(line.charAt(i) == '0'){
                        a[l][i] = 0;
                    }
                    else {
                        a[l][i] = 1;
                    }
                }
                l++;
            }
            return a;
        }
    }


}
