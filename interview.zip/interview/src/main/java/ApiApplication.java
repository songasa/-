package main.java;

import main.java.api.MazeAlgorithm;
import main.java.controller.ChangeMaze;

import main.java.controller.MyStack;
import main.java.controller.RCMaze;
import main.java.entry.Position;
import main.java.imp.MazePath;
import main.java.imp.MazePathByBFS;
import main.java.transfer.EntrancePosition;


import java.io.FileNotFoundException;
import java.util.Scanner;


public class ApiApplication {
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("逃出迷宫！");
        System.out.println();
        System.out.println("请先讲所有迷宫文件放置在安装目录下 和 本exe程序同级");
        System.out.println();

        //1.读取文件名称,获取入口位置
        //根路径
        String rootPath = System.getProperty ("user.dir");
        System.out.println ("请输入将要运行的迷宫文件名称输入(包括文件格式.txt)");
        Scanner sc = new Scanner (System.in);
        //文件名称
        String file = sc.nextLine ( );
        //拼接成迷宫文件绝对路径
        String FileName = rootPath + "/" + file;

        //2.获取文件的信息
        //入口位置
        int[] en = EntrancePosition.entrance (FileName);
        //迷宫行数x
        int x = RCMaze.RMaze(FileName);
        //迷宫列数y
        int y = RCMaze.CMaze(FileName);
        //返回二维迷宫标准数组
        int[][] mazeArray = ChangeMaze.Change(FileName,x,y);

        //3.逃离迷宫
        //3.1初始位置
        MyStack<Position> myStack = new MyStack<>();
        myStack.push(new Position(en[0],en[1]));

        //3.2记录最优路径
        //定义最短路径栈
        MyStack<Position> minMyStack = new MyStack<>();
        //一直调用MazePath，保持minMyStack栈为最优路径
        MazeAlgorithm mazeAlgorithm = new MazePath();
        mazeAlgorithm.getMinStack (en, mazeArray,myStack,minMyStack);

        //4.打印最短路径
        for (Position position : minMyStack.list) {
            System.out.println (position.toString ( ));
        }
        System.out.println("已通过2个栈的组合使用完成任务！");

        System.out.println();
        System.out.println ("下面是方法2：广度优先遍历，最短路径(*),是(1)否(0)执行");
        Scanner sc2 = new Scanner(System.in);
        int temp = sc2.nextInt();
        if(temp==1){
            MazePathByBFS maze2 = new MazePathByBFS (RCMaze.RMaze(file), RCMaze.CMaze(file));
            //全部遍历，每个点进行可行MazeNode属性情况写入
            for (int i = 0; i < RCMaze.RMaze(file); i++) {
                for (int j = 0; j < RCMaze.CMaze(file); j++) {
                    maze2.initMazeNode (mazeArray[i][j], i, j);
                }
            }
            //修改迷宫所有节点四个方向的行走状态信息
            maze2.initMazeNodePathState ( );
            // 寻找迷宫路径
            int[] ex = new int[2];
            ex = maze2.findMazePath (en, ex);
            // 打印迷宫路径搜索的结果
            maze2.showMazePath (ex);
            System.out.println("拜拜！");
        }
        else {
            System.out.println("拜拜！");
        }
    }
}
