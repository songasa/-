package main.java.imp;

import main.java.api.MazeAlgorithm;
import main.java.controller.MyStack;
import main.java.entry.Position;


/**
 * 最短路径算法------用递归深度遍历回溯最短路径算法
 */
public class MazePath implements MazeAlgorithm {


    /**
     * 功能描述：利用递归深度遍历回溯最短路径算法
     *
     * @param en           入口位置
     * @param mazeArray    迷宫数组形式
     * @param stackUtil    记录路径栈
     * @param minStackUtil 最优记录路径栈
     */
    @Override
    public void getMinStack(int[] en, int[][] mazeArray, MyStack<Position> stackUtil, MyStack<Position> minStackUtil) {
        //迷宫大小
        int x = mazeArray.length;
        int y = mazeArray[0].length;
        //当前坐标位置,上一个坐标位置
        Position cur = stackUtil.peek ( );
        Position next = cur.clone ( );

        //出口边界 在四边即为出口 且不为入口
        if ((cur.getX ( ) == 0 || cur.getY ( ) == 0 || cur.getX ( ) == x - 1 || cur.getY ( ) == y - 1) &&
                (cur.getX ( ) != en[0] || cur.getY ( ) != en[1])) {
            //追找最优路径条件  使min栈永远保持最短距离的路径
            if (minStackUtil.size ( ) == 0 || minStackUtil.size ( ) > stackUtil.size ( )
                    && ((cur.getX ( ) != en[0] && cur.getY ( ) != en[1]))) {
                //不能直接赋值,对象之前赋值的是引用;实现迷宫对象Cloneable接口,重写clone方法
                minStackUtil.clear ( );
                for (Position position : stackUtil.list) {
                    //克隆当前路径 写入minMyStack栈
                    minStackUtil.push (position.clone ( ));
                }
            }
        }

        //向下
        next.setX (cur.getX ( ) + 1);
        if (CheckIsAccess (mazeArray, next)) {
            stackUtil.push (next);
            //下一个路径标记为2
            mazeArray[next.getX ( )][next.getY ( )] = 2;

            getMinStack (en, mazeArray, stackUtil, minStackUtil);
            //抛出下一个路径 下方继续遍历其他方向的情况 以达到最短距离
            stackUtil.pop ( );

            //上个路径情况继续保持为0 可行路径
            mazeArray[next.getX ( )][next.getY ( )] = 0;
        }

        //向右 注意：赋值时使用深克隆
        next = cur.clone ( );
        next.setY (cur.getY ( ) + 1);
        if (CheckIsAccess (mazeArray, next)) {
            stackUtil.push (next);
            mazeArray[next.getX ( )][next.getY ( )] = 2;
            getMinStack (en, mazeArray, stackUtil, minStackUtil);
            stackUtil.pop ( );
            mazeArray[next.getX ( )][next.getY ( )] = 0;
        }

        //向左
        next = cur.clone ( );
        next.setY (cur.getY ( ) - 1);
        if (CheckIsAccess (mazeArray, next)) {
            stackUtil.push (next);
            mazeArray[next.getX ( )][next.getY ( )] = 2;
            getMinStack (en, mazeArray, stackUtil, minStackUtil);
            stackUtil.pop ( );
            mazeArray[next.getX ( )][next.getY ( )] = 0;
        }

        //向上
        next = cur.clone ( );
        next.setX (cur.getX ( ) - 1);
        if (CheckIsAccess (mazeArray, next)) {
            stackUtil.push (next);
            mazeArray[next.getX ( )][next.getY ( )] = 2;
            getMinStack (en, mazeArray, stackUtil, minStackUtil);
            stackUtil.pop ( );
            mazeArray[next.getX ( )][next.getY ( )] = 0;
        }
    }


    /**
     * 功能描述：下一个位置是否可达
     *
     * @param mazeArray 迷宫数组
     * @param cur       当前位置
     * @return
     */
    public Boolean CheckIsAccess(int mazeArray[][], Position cur) {
        //迷宫大小
        int x = mazeArray.length;
        int y = mazeArray[0].length;
        if (cur.getX ( ) >= 0 && cur.getX ( ) < x
                && cur.getY ( ) >= 0 && cur.getY ( ) < y
                && mazeArray[cur.getX ( )][cur.getY ( )] == 0) {
            return true;
        }
        return false;
    }

}
